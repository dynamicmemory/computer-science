file://<HOME>/server/computer-science/11-programming%20paradigms/assignments/2024assignment1-main/src/main/scala/cosc250/assignmentOne/Challenge2.scala
### java.nio.file.NoSuchFileException: <HOME>/server/computer-science/11-programming paradigms/assignments/2024assignment1-main/jar:file:<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.15/scala-library-2.13.15-sources.jar!/scala/collection/immutable/Seq.scala

occurred in the presentation compiler.

presentation compiler configuration:


action parameters:
offset: 3111
uri: file://<HOME>/server/computer-science/11-programming%20paradigms/assignments/2024assignment1-main/src/main/scala/cosc250/assignmentOne/Challenge2.scala
text:
```scala
package cosc250.assignmentOne

/**
 * In Challenge 2, the functions you will implement will produce a Scrabble scorer. 
 * It should take into account the letters in the word *and* the squares the word sits on.
 * 
 * Again, where you see ??? you need to write the implementation of the function.
 */
object Challenge2 {

  /**
    *
    * I've created a sealed trait to model the different kinds of square. A "sealed trait" means that every class or
    * object that implements that trait is defined in the same program file. Knowing that there aren't any other
    * potential Squares out there (eg, being added later by other programmers) means the compiler can do cleverer
    * exhaustiveness-checking for us.
    *
    */
  sealed trait Square
  case object OrdinarySquare extends Square
  case object DoubleLetterScore extends Square
  case object TripleLetterScore extends Square
  case object DoubleWordScore extends Square
  case object TripleWordScore extends Square

  /**
  * (You may assume all letters are uppercase)
  *
  * 1: A, E, I, O, U, L, N, S, T, R.
  * 2: D, G.
  * 3: B, C, M, P.
  * 4: F, H, V, W, Y.
  * 5: K
  * 8: J, X.
  * 10: Q, Z.
  *
  * You might find using "mystring".contains(char) useful to keep it short
  */
  def letterScore(char:Char):Int = { 
    char match  
      case c if "AEIOULNSTR".contains(c) => 1
      case c if "DG".contains(c) => 2 
      case c if "BCMP".contains(c) => 3
      case c if "FHVWY".contains(c) => 4
      case c if "K".contains(c) => 5
      case c if "JX".contains(c) => 8
      case c if "QZ".contains(c) => 10
  }

  /**
    * This should work out what this letter scores, given the square it's on.
    * Don't forget - DoubleWordScores etc affect the word as a whole, not individual letters
    */
  def letterAndSquareScore(char:Char, sq:Square):Int = {
    sq match 
      case OrdinarySquare => letterScore(char) // Not sure if i need this since _  
      case DoubleLetterScore => letterScore(char) * 2 
      case TripleLetterScore => letterScore(char) * 3 
      case _ => letterScore(char)
  }

  /** 
   This should work out the total score for each letter, given the square it's on.
    At this stage, DoubleWordScores etc should not be taken into account. Only Double and TripleLetterScores.

    Hint: you can "zip" a word with a Seq to produce a Seq of (char, Square) tuples.
    eg, "ABC".zip(Seq(1, 2, 3)) produces Seq(('A', 1), ('B', 2), ('C', 3))

    Hint: If you produce a Seq[Int] you can call seq.sum on it.
    */
  
  def totalLetterScore(word:String, squares:Seq[Square]):Int = {
    word.zip(squares).map { 
      case (char, sq) => letterAndSquareScore(char, sq)
      }.sum
  }

  /**
    Calculate the scrabble score for a word on a set of squares.
    Now we have to take DoubleWordScore and TripleWordScore squares into account.
    They combine multiplicatively. So, if there are two TripleWordScores and a DoubleWordScore
    squares, the multiplier will be 3 * 3 * 2 = 18
    */
  def scrabbleScore(word:String, squares:Seq[Square]):Int = {
    var score = totalLetterScore(word, squares)

    squares mat@@



    ???
  }

}

```



#### Error stacktrace:

```
java.base/sun.nio.fs.UnixException.translateToIOException(UnixException.java:92)
	java.base/sun.nio.fs.UnixException.rethrowAsIOException(UnixException.java:106)
	java.base/sun.nio.fs.UnixException.rethrowAsIOException(UnixException.java:111)
	java.base/sun.nio.fs.UnixFileSystemProvider.newByteChannel(UnixFileSystemProvider.java:218)
	java.base/java.nio.file.Files.newByteChannel(Files.java:380)
	java.base/java.nio.file.Files.newByteChannel(Files.java:432)
	java.base/java.nio.file.Files.readAllBytes(Files.java:3288)
	scala.meta.internal.io.PlatformFileIO$.slurp(PlatformFileIO.scala:42)
	scala.meta.internal.io.FileIO$.slurp(FileIO.scala:18)
	scala.meta.internal.mtags.ScalametaCommonEnrichments$XtensionAbsolutePath.toInput(ScalametaCommonEnrichments.scala:467)
	scala.meta.internal.mtags.Mtags.toplevels(Mtags.scala:28)
	scala.meta.internal.mtags.Mtags.topLevelSymbols(Mtags.scala:85)
	scala.meta.internal.mtags.Mtags$.topLevelSymbols(Mtags.scala:180)
	scala.meta.internal.metals.MetalsSymbolSearch.$anonfun$definitionSourceToplevels$7(MetalsSymbolSearch.scala:93)
	scala.collection.concurrent.TrieMap.getOrElseUpdate(TrieMap.scala:960)
	scala.meta.internal.metals.MetalsSymbolSearch.$anonfun$definitionSourceToplevels$2(MetalsSymbolSearch.scala:93)
	scala.Option.map(Option.scala:242)
	scala.meta.internal.metals.MetalsSymbolSearch.definitionSourceToplevels(MetalsSymbolSearch.scala:69)
	dotty.tools.pc.completions.CaseKeywordCompletion$.dotty$tools$pc$completions$CaseKeywordCompletion$$$sortSubclasses(MatchCaseCompletions.scala:342)
	dotty.tools.pc.completions.CaseKeywordCompletion$.matchContribute(MatchCaseCompletions.scala:292)
	dotty.tools.pc.completions.Completions.advancedCompletions(Completions.scala:349)
	dotty.tools.pc.completions.Completions.completions(Completions.scala:122)
	dotty.tools.pc.completions.CompletionProvider.completions(CompletionProvider.scala:139)
	dotty.tools.pc.ScalaPresentationCompiler.complete$$anonfun$1(ScalaPresentationCompiler.scala:150)
```
#### Short summary: 

java.nio.file.NoSuchFileException: <HOME>/server/computer-science/11-programming paradigms/assignments/2024assignment1-main/jar:file:<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.15/scala-library-2.13.15-sources.jar!/scala/collection/immutable/Seq.scala