
//> using test.dep "org.scalameta::munit::1.1.0"

class EmptyTest extends munit.FunSuite {

    test("The test framework runs") {
        assert(true)
    }
}