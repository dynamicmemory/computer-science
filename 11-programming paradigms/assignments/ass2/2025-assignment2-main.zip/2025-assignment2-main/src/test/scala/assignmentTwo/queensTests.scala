package assignmentTwo.queens

class QueensTests extends munit.FunSuite {

    // A place for you to keep tests you write


    
}