#include "expression_tree.h" 

int main()
{
	// Store parenthetized expression
	std::vector<char> input{'(', '2', '+', '(', '3', '*', 
				'(', '2', '+', '2', ')', ')', ')', '+', '5'};

	Expression_Tree a;
	
	if (a.empty())
		std::cout << "empty" << std::endl;
	else
		std::cout << "not empty" << std::endl;
	
	a.build_expression_tree(input);
	
	if (a.empty())
		std::cout << "empty" << std::endl;
	else
		std::cout << "not empty" << std::endl;

	std::cout << "Original input: ";
	std::vector<char>::const_iterator it;
	for (it = input.begin(); it != input.end(); it++) {
		std::cout << *it;
	}
	std::cout << std::endl;

	std::cout << "Input in prefix notation: ";
	a.preorder_walk();
	std::cout << std::endl;

	std::cout << "Input in infix notation: ";
	a.inorder_walk();
	std::cout << std::endl;

	std::cout << "Input in postfix notation: ";
	a.postorder_walk();
	std::cout << std::endl;


	return 0;
}
