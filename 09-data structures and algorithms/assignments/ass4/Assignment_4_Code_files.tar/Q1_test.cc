#include "bst.h"

int main()
{
	// Best-case BST (check using ddd)
	Binary_Search_Tree<int> T1;
	
	T1.insert(4), T1.insert(2), T1.insert(6), T1.insert(1);
	T1.insert(3), T1.insert(5), T1.insert(7);
	
	// Check keys are in sorted order: 1,2,3,4,5,6,7.
	T1.inorder_walk();
	
	// Worst-case BST (check using ddd)
	Binary_Search_Tree<int> T2;
	
	T2.insert(1), T2.insert(2), T2.insert(3), T2.insert(4);
	T2.insert(5), T2.insert(6), T2.insert(7);


	return 0;
}
