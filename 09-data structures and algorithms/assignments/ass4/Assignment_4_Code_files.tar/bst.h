#include <iostream>

template<class T>
class Node {
public:
	Node() : key() { par = 0, left = 0, right = 0; }
	Node(T a, Node<T>* b = 0, Node<T>* c = 0, Node<T>* d = 0) 
	{ 
		key = a, par = b, left = c, right = d; 
	}
	T key;
	Node<T> *par, *left, *right;	
};

template<class T>
class Binary_Search_Tree {
public:
	Binary_Search_Tree() { root = 0; }	
	~Binary_Search_Tree() { postorder_delete(); }
	bool empty() { return root == 0; }
	void insert(T k) { insert(new Node<T>(k)); }
	void insert(Node<T>*);
	void inorder_walk() { inorder_walk(root), std::cout << std::endl; }
	void inorder_walk(Node<T>*);
	void postorder_delete() { postorder_delete(root); }
	void postorder_delete(Node<T>*);
	Node<T>* search(T k) { return search(root, k); }
	Node<T>* search(Node<T>*, T);
	Node<T>* minimum(Node<T>*);
	void transplant(Node<T>*, Node<T>*);
	void remove(Node<T>*);	
private:
	Node<T>* root;
};

template<class T>
void Binary_Search_Tree<T>::insert(Node<T>* p)
{
	Node<T>* parent = 0;
	Node<T>* q = root;
	
	while (q != 0) {
		parent = q;
		if (p->key < q->key)
			q = q->left;
		else
			q = q->right;
	}
	p->par = parent;
	if (parent == 0)
		root = p;
	else if (p->key < parent->key)
		parent->left = p;
	else
		parent->right = p;
}

template<class T>
void Binary_Search_Tree<T>::inorder_walk(Node<T>* p)
{
	if (p != 0) {
		inorder_walk(p->left);
		std::cout << p->key << " ";
		inorder_walk(p->right);
	}	
}

template<class T>
void Binary_Search_Tree<T>::postorder_delete(Node<T>* p)
{
	if (p != 0) {
		postorder_delete(p->left);
		postorder_delete(p->right);
		delete p;
	}	
}

template<class T>
Node<T>* Binary_Search_Tree<T>::search(Node<T>* p, T k)
{
	while (p != 0 && k != p->key) {
		if (k < p->key)
			p = p->left;
		else
			p = p->right;
	}		
	return p;
}

template<class T>
Node<T>* Binary_Search_Tree<T>::minimum(Node<T>* p)
{
	while (p->left != 0)
		p = p->left;
	
	return p;
}

template<class T>
void Binary_Search_Tree<T>::transplant(Node<T>* p, Node<T>* q)
{
	if (p->par == 0)
		root = q;
	else if (p == (p->par)->left)
		(p->par)->left = q;
	else
		(p->par)->right = q;
	
	if (q != 0)
		q->par = p->par;
}

template<class T>
void Binary_Search_Tree<T>::remove(Node<T>* p)
{
	if (p->left == 0)
		transplant(p, p->right);
	else if (p->right == 0)
		transplant(p, p->left);
	else {
		Node<T>* q = minimum(p->right);
		if (q->par != p) {
			transplant(q, q->right);
			q->right = p->right;
			(q->right)->par = q;
		}
		transplant(p, q);
		q->left = p->left;
		(q->left)->par = q;
	}
	delete p;
}



