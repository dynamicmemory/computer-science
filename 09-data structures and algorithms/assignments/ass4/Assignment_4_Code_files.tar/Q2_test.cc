#include "rbt.h"

int main()
{
	// Worst-case BST (check using ddd)
	Red_Black_Tree<int> T;
	
	T.insert(1), T.insert(2), T.insert(3), T.insert(4);
	T.insert(5), T.insert(6);
	
	T.inorder_leaf_black_height(); // should be 2,2,2,2,2,2,2

	return 0; 
}
