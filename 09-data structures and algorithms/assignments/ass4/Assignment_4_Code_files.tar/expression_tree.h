#include <stack>
#include <vector>
#include <iostream>

// A very simple expression tree class that converts a parenthetized input 
// consisting of addition and multiplication operations, into an expression tree.
// Traversal of this expression tree generates various Polish notations.

template<class T>
class Node {
public:
	Node() : key() { left = 0, right = 0; }
	Node(T a, Node<T>* b = 0, Node<T>* c = 0) 
	{ 
		key = a, left = b, right = c; 
	}
	T key;
	Node<T> *left, *right;	
};

class Expression_Tree { 
public:
	Expression_Tree() { root = 0; }
	~Expression_Tree() { postorder_delete(root); }
	bool empty() { return root == 0; }
	void build_expression_tree(std::vector<char>&);
	void postorder_delete() { postorder_delete(root); }
	void postorder_delete(Node<char>*);
	void preorder_walk() { preorder_walk(root); }
	void preorder_walk(Node<char>*);
	void inorder_walk() { inorder_walk(root); }
	void inorder_walk(Node<char>*);
	void postorder_walk() {postorder_walk(root); }
	void postorder_walk(Node<char>*);
private:
	Node<char>* root;
};

void Expression_Tree::postorder_delete(Node<char>* p)
{
	if (p != 0) {
		postorder_delete(p->left);
		postorder_delete(p->right);
		delete p;
	}	
}

void Expression_Tree::preorder_walk(Node<char>* p) 
{
    if (p != 0) {
    	std::cout << p->key ;
        preorder_walk(p->left);
        preorder_walk(p->right);
    }
}

void Expression_Tree::inorder_walk(Node<char>* p)
{
	if (p != 0) {
		inorder_walk(p->left);
		std::cout << p->key;
		inorder_walk(p->right);
	}	
}

void Expression_Tree::postorder_walk(Node<char>* p) 
{
    if (p != 0) {
   		postorder_walk(p->left);
        postorder_walk(p->right);
        std::cout << p->key;
    }
}

void Expression_Tree::build_expression_tree(std::vector<char>& input) {  }
